CREATE PROCEDURE LCADUSER.DS_P_UPDATE_TRIP_LEG ( IN P_CC_CODE INT,
                                                         IN P_DATE_OF_TRIP DATE,
                                                         IN P_TRIP_ID INT,
                                                         IN P_TRIP_LEG CHAR(1),
                                                         IN P_PU_ADDRESS_CODE INT,
                                                         IN P_PU_APARTMENT CHAR(10),
                                                         IN P_PU_PHONE_AC SMALLINT,
                                                         IN P_PU_PHONE INT,
                                                         -- IN P_PU_PHONE_EXT CHAR(6),
                                                         IN P_PU_FACILITY_CODE INT,
                                                         IN P_PU_TIME TIMESTAMP,
                                                         IN P_DO_ADDRESS_CODE INT,
                                                         IN P_DO_APARTMENT CHAR(10),
                                                         IN P_DO_PHONE_AC SMALLINT,
                                                         IN P_DO_PHONE INT,
                                                         -- IN P_DO_PHONE_EXT CHAR(6),
                                                         IN P_DO_FACILITY_CODE INT,
                                                         IN P_DO_TIME TIMESTAMP,
                                                         IN P_APPOINTMENT_TIME TIMESTAMP,
                                                         IN P_TP_CODE INT,
                                                         IN P_STATUS SMALLINT,
                                                         IN P_USER_CODE INT,
                                                         INOUT P_MILES INT,
                                                         -- IN P_COST INT,
                                                         -- IN P_ACTUAL_PU_TIME TIMESTAMP,
                                                         -- IN P_ACTUAL_DO_TIME TIMESTAMP,
                                                         IN P_PU_BUILDING VARCHAR(30),
                                                         IN P_DO_BUILDING VARCHAR(30),
                                                         IN P_PU_DIRECTIONS VARCHAR(80),
                                                         IN P_DO_DIRECTIONS VARCHAR(80),
                                                         -- IN P_PU_PHYSICIAN INT,
                                                         -- IN P_DO_PHYSICIAN INT,
                                                         -- IN P_WILLCALL_RECVD TIMESTAMP,
                                                         -- IN P_VEHICLE_CODE INT,
                                                         -- IN P_COPAY INT,     -- todo : needed in out call
                                                         IN P_CANCEL_CODE INT,
                                                         -- IN P_TP_OVERRIDE_CODE INT,
                                                         -- IN P_ACTUAL_PU_ODOM INT,
                                                         -- IN P_ACTUAL_DO_ODOM INT,
                                                         -- IN P_PUBLIC_TRANSIT SMALLINT,
                                                         -- IN P_TRIPLEG_LOOKUP_A INT,
                                                         -- IN P_TRIPLEG_LOOKUP_B INT,
                                                         -- IN P_TRIPLEG_LOOKUP_C INT,
                                                         -- IN P_TRIP_LEG_TEXT_A VARCHAR(60),
                                                         -- IN P_TRIP_LEG_TEXT_B VARCHAR(60),
                                                         -- IN P_TRIP_LEG_TEXT_C VARCHAR(60),
                                                         -- IN P_TRIP_LEG_TEXT_D VARCHAR(60),
                                                         -- IN P_TRIP_LEG_TEXT_E VARCHAR(60),
                                                         -- IN P_RECOVERY_USER_CODE INT,
                                                         -- IN P_RECOVERY_STATE SMALLINT,
                                                         -- IN P_COST_OVERRIDE CHAR(1),
                                                         INOUT P_ESTIMATED_COST INT,
                                                         -- IN P_PAID_LOS_CODE INT,
                                                         -- IN P_BATCH_CODE INT,
                                                         -- IN P_COPAY_COLLECTED INT,
                                                         -- IN P_DRIVER_CODE INT,
                                                         -- IN P_VOUCHER_NUMBER VARCHAR(12),
                                                         -- IN P_TRANSFER CHAR(1),
                                                         -- IN P_WAIT_HOURS INTEGER,
                                                         -- IN P_INCUR_WAIT_CHG CHAR(1),
                                                         -- IN P_INCUR_ASSIST_CHG CHAR(1),
                                                         -- IN P_RIDER_OCC_CODE INT,
                                                         -- IN P_COST_OR_APPROVE_BY INT,
                                                         IN P_CANCEL_SOURCE INT,
                                                         -- IN P_INCUR_INCENTIVE CHAR(1),
                                                         -- IN P_INCUR_DISCOUNT CHAR(1),
                                                         -- IN P_INCUR_ADMIN_CHG CHAR(1),
                                                         -- IN P_RIDER_SIGN_CODE INT,
                                                         -- IN P_SUPPLIED_TIMESTAMP TIMESTAMP,
                                                         -- IN P_USE_SUPPLIED_TS SMALLINT,
                                                         INOUT P_MILES_STATUS SMALLINT,
                                                         OUT P_UPDATED_ON TIMESTAMP,
                                                         IN p_Last_Updated_On TIMESTAMP,
                                                         OUT p_Verified_By int,
                                                         OUT p_Verified_ON timestamp,
                                                         -- IN p_Miles_Override smallint,
                                                         -- IN p_Miles_OR_Approved_By int,
                                                         -- IN p_Use_Trip_Limit_Module smallint,
                                                         -- IN p_Limit_Override_Reason_Code int,
                                                         -- in p_Limit_Override_By int,
                                                         -- IN p_TOTAL_COST_ADJUSTMENTS int,
                                                         -- in p_SCHEDULED_WAIT_CHARGE SMALLINT, 
                                                         -- in p_SCHEDULED_WAIT_TIME INTEGER, 
                                                         -- in p_SCHEDULED_ASSIST_CHARGE SMALLINT, 
                                                         -- in p_WAIT_CHG_APPROVED_BY INTEGER,
                                                         -- in p_ASSIST_CHG_APPROVED_BY INTEGER, 
                                                         inout p_Address_Miles_Last_Miles_Source smallint,
                                                         -- IN p_Requested_PU_Time timestamp,
                                                         -- IN p_TP_Dispatched_Time timestamp,
                                                         -- IN p_Billed_Cost int,
                                                         IN P_ASSISTANCE_TYPE_CODE INTEGER,
                                                         -- IN P_CLIENT_AUTH_NUMBER varchar(20),
                                                         -- IN p_OVERRIDE_COST int,
                                                         -- IN p_MASS_TRANSIT_OR_APPROVED_BY integer,
                                                         -- IN p_MEDICAL_FORM_OR_APPROVED_BY integer,
                                                         -- IN p_BILLED_COST_OR_APPROVED_BY integer,
                                                         -- IN p_Spenddown integer,
                                                         OUT p_Region_Code integer,
                                                         OUT p_Broker_Client_Code integer,
                                                         OUT p_Belongs_To_Call_Center_Code integer,
                                                         OUT p_AML_Updated_On timestamp,
                                                         OUT SQLSTATE_OUT CHAR(5),
                                                         OUT SQLCODE_OUT INT,
                                                         OUT MESSAGE_TEXT_OUT VARCHAR(1000))
    SPECIFIC LCADUSER.P_UPDATE_TRIP_LEG
    DYNAMIC RESULT SETS 0
    MODIFIES SQL DATA
    NOT DETERMINISTIC
    CALLED ON NULL INPUT
    LANGUAGE SQL
------------------------------------------------------------------------
--- CQ 5929 8038
-- LOG-1386
------------------------------------------------------------------------
P1UTL: BEGIN -- ATOMIC
    -- DECLARE VARIABLES
    DECLARE SQLSTATE CHAR(5) DEFAULT '00000';
    DECLARE SQLCODE INT DEFAULT 0;
    DECLARE NOW TIMESTAMP;

    DECLARE N_CC_CODE INT;
    DECLARE N_DATE_OF_TRIP DATE;
    DECLARE N_TRIP_ID INT;
    DECLARE N_TRIP_LEG CHAR(1);
    DECLARE N_PU_ADDRESS_CODE INT;
    DECLARE N_PU_APARTMENT CHAR(10);
    DECLARE N_PU_PHONE_AC SMALLINT;
    DECLARE N_PU_PHONE INT;
    DECLARE N_PU_PHONE_EXT CHAR(6);
    DECLARE N_PU_FACILITY_CODE INT;
    DECLARE N_PU_TIME TIMESTAMP;
    DECLARE N_DO_ADDRESS_CODE INT;
    DECLARE N_DO_APARTMENT CHAR(10);
    DECLARE N_DO_PHONE_AC SMALLINT;
    DECLARE N_DO_PHONE INT;
    DECLARE N_DO_PHONE_EXT CHAR(6);
    DECLARE N_DO_FACILITY_CODE INT;
    DECLARE N_DO_TIME TIMESTAMP;
    DECLARE N_APPOINTMENT_TIME TIMESTAMP;
    DECLARE N_TP_CODE INT;
    DECLARE N_STATUS SMALLINT;
    DECLARE N_UPDATED_BY INT;
    DECLARE N_UPDATED_ON TIMESTAMP;
    DECLARE N_MILES INT;
    DECLARE N_COST INT;
    DECLARE N_ACTUAL_PU_TIME TIMESTAMP;
    DECLARE N_ACTUAL_DO_TIME TIMESTAMP;
    DECLARE N_PU_BUILDING VARCHAR(30);
    DECLARE N_DO_BUILDING VARCHAR(30);
    DECLARE N_PU_DIRECTIONS VARCHAR(80);
    DECLARE N_DO_DIRECTIONS VARCHAR(80);
    DECLARE N_PU_PHYSICIAN INT;
    DECLARE N_DO_PHYSICIAN INT;
    DECLARE N_WILLCALL_RECVD TIMESTAMP;
    DECLARE N_VEHICLE_CODE INT;
    DECLARE N_COPAY INT;
    DECLARE N_CANCEL_CODE INT;
    DECLARE N_TP_OVERRIDE_CODE INT;
    DECLARE N_ACTUAL_PU_ODOM INT;
    DECLARE N_ACTUAL_DO_ODOM INT;
    DECLARE N_PUBLIC_TRANSIT SMALLINT;
    DECLARE N_TRIPLEG_LOOKUP_A INT;
    DECLARE N_TRIPLEG_LOOKUP_B INT;
    DECLARE N_TRIPLEG_LOOKUP_C INT;
    DECLARE N_TRIP_LEG_TEXT_A VARCHAR(60);
    DECLARE N_TRIP_LEG_TEXT_B VARCHAR(60);
    DECLARE N_TRIP_LEG_TEXT_C VARCHAR(60);
    DECLARE N_TRIP_LEG_TEXT_D VARCHAR(60);
    DECLARE N_TRIP_LEG_TEXT_E VARCHAR(60);
    DECLARE N_RECOVERY_USER_CODE INT;
    DECLARE N_RECOVERY_STATE SMALLINT;
    DECLARE N_COST_OVERRIDE CHAR(1);
    DECLARE N_ESTIMATED_COST INT;
    DECLARE N_PAID_LOS_CODE INT;
    DECLARE N_BATCH_CODE INT;
    DECLARE N_COPAY_COLLECTED INT;
    DECLARE N_DRIVER_CODE INT;
    DECLARE N_VOUCHER_NUMBER VARCHAR(12);
    DECLARE N_TRANSFER CHAR(1);
    DECLARE N_WAIT_HOURS INTEGER;
    DECLARE N_INCUR_WAIT_CHG CHAR(1);
    DECLARE N_INCUR_ASSIST_CHG CHAR(1);
    DECLARE N_RIDER_OCC_CODE INT;
    DECLARE N_COST_OR_APPROVE_BY INT;
    DECLARE N_CANCEL_SOURCE INT;
    DECLARE N_INCUR_INCENTIVE CHAR(1);
    DECLARE N_INCUR_DISCOUNT CHAR(1);
    DECLARE N_INCUR_ADMIN_CHG CHAR(1);
    DECLARE N_RIDER_SIGN_CODE INT;
    DECLARE n_Verified_By int;
    DECLARE n_Verified_On timestamp;
    DECLARE n_Miles_Override smallint;
    DECLARE n_Miles_OR_Approved_By int;
    DECLARE N_Total_Cost_Adjustments int;
    DECLARE n_SCHEDULED_WAIT_CHARGE SMALLINT;
    DECLARE n_SCHEDULED_WAIT_TIME INTEGER;
    DECLARE n_SCHEDULED_ASSIST_CHARGE SMALLINT; 
    declare n_WAIT_CHG_APPROVED_BY INTEGER;
    declare n_ASSIST_CHG_APPROVED_BY INTEGER;
    DECLARE n_AML_UPDATED_On timestamp;
    DECLARE n_Requested_PU_Time timestamp;
    DECLARE n_TP_Dispatched_Time timestamp;
    DECLARE n_Billed_Cost integer;
    DECLARE N_ASSISTANCE_TYPE_CODE INTEGER;
    DECLARE N_CLIENT_AUTH_NUMBER varchar(20);
    DECLARE N_OVERRIDE_COST INT;
    DECLARE N_MASS_TRANSIT_OR_APPROVED_BY integer;
    DECLARE N_MEDICAL_FORM_OR_APPROVED_BY integer;
    DECLARE n_BILLED_COST_OR_APPROVED_BY integer;
    DECLARE n_Spenddown integer;

    DECLARE z_Preschedule_Code integer;
    DECLARE z_LOS_CODE INTEGER;
    DECLARE z_START_DATE DATE ;
    DECLARE z_EXPIRE_DATE DATE;
    DECLARE z_Next_Date_Of_Trip DATE;
    DECLARE z_USER_CODE INTEGER ;
    DECLARE z_PRESCHED_DAYS_CODE SMALLINT ;
    DECLARE z_PCA SMALLINT ;
    DECLARE z_ADULT_ESCORTS SMALLINT ;
    DECLARE z_CHILD_ESCORTS SMALLINT ;
    DECLARE z_CARSEATS SMALLINT ;
    DECLARE z_TRIP_REASON_CODE INTEGER ;
    DECLARE z_TREAT_TYPE_CODE INTEGER ;
    DECLARE z_COMMENTS_FOR_TP VARCHAR(200) ;
    DECLARE z_REQUESTED_BY VARCHAR(100) ;
    DECLARE z_REQD_BY_PHONE INTEGER ;
    DECLARE z_REQD_BY_PHONE_AC SMALLINT ;
    DECLARE z_REQD_BY_REL SMALLINT ;
    DECLARE z_GAS_REIMB_OP_CODE INTEGER ;
    DECLARE z_GAS_REIMB_REL_CODE SMALLINT ;
    DECLARE z_TRIP_LOOKUP_A INTEGER ;
    DECLARE z_TRIP_LOOKUP_B INTEGER ;
    DECLARE z_TRIP_LOOKUP_C INTEGER ;
    DECLARE z_TRIP_TEXT_A VARCHAR(60) ;
    DECLARE z_TRIP_TEXT_B VARCHAR(60) ;
    DECLARE z_TRIP_TEXT_C VARCHAR(60) ;
    DECLARE z_TRIP_TEXT_D VARCHAR(60) ;
    DECLARE z_TRIP_TEXT_E VARCHAR(60);
    DECLARE z_STATUS INTEGER;
    DECLARE z_DIAGNOSTIC_CODE INTEGER;
    DECLARE z_AUTHORIZED_BY_CODE INTEGER;
    DECLARE z_LAST_DATE_OF_TRIP DATE;
    DECLARE z_NUMBER_OF_TRIPS INT;
    DECLARE z_NUM_TRIPS_LEFT INT;
    DECLARE z_HOLIDAY_CODE INT;
    DECLARE z_REGION_CODE INT;
    DECLARE z_Condition varchar(80);
    DECLARE z_Number_Trips_Verified int;
    DECLARE z_Expire_Reason_Code int;
    DECLARE z_Expire_Contact varchar(40);
    DECLARE z_Recertify_Date date;
    DECLARE z_Last_Updated_On TIMESTAMP;
    DECLARE z_Updated_On TIMESTAMP;
    DECLARE n_LOS_CODE int;
    DECLARE n_PCA smallint;
    DECLARE n_Adult_Escorts smallint;
    DECLARE n_Child_Escorts smallint;
    DECLARE a_Actual_Cost_Calc int;
    DECLARE a_FFS_Cost_Calc int;
    DECLARE a_Rate_Code int;
    DECLARE a_Rate_Found smallint;
--    DECLARE x_region_code int;
--    DECLARE x_BC_CODE int;
    DECLARE z_Verified_By int;
    DECLARE z_Verified_On timestamp;
    DECLARE z_Miles_Override smallint;
    DECLARE z_Miles_OR_Approved_By int;
    
    DECLARE x_Something_Changed int;

    DECLARE z_Incur_WAIT_CHG char(1);
    DECLARE z_Incur_ASSIST_CHG char(1);
    DECLARE z_Incur_PCA_CHG char(1);
    DECLARE z_Incur_ADULT_CHG char(1);
    DECLARE z_Incur_CHILD_CHG char(1);
    DECLARE a_PCA_Rate int;
    DECLARE a_Adult_Escorts_Rate int;
    DECLARE a_Child_Escorts_Rate int;
    DECLARE a_Wait_Rate int;
    DECLARE a_Assist_Rate int;
    DECLARE a_Used_Master_Rate smallint;

    DECLARE N_BC_CODE INT;
    DECLARE n_Rider_Code int;
    DECLARE n_Rider_Type_Code int;
    DECLARE n_Treat_Type_Code int;
    DECLARE N_Region_Code int;
    DECLARE n_Belongs_To_Call_Center_Code int;
    DECLARE n_Broker_Client_Code int;

    DECLARE z_PCA_CHG_APPROVED_BY INTEGER;
    DECLARE z_ADULT_ESC_CHG_APPROVED_BY INTEGER;
    DECLARE z_CHILD_ESC_CHG_APPROVED_BY INTEGER; 
    DECLARE z_ORDERING_MED_PROV_NAME VARCHAR (60);
    DECLARE z_ORDERING_MED_PROV_ID VARCHAR (20);

    DECLARE n_BC_Copay_Copay int;
    DECLARE n_BC_Copay_Subtract_From_Cost smallint;
    DECLARE n_Do_Copay_Subtract char(1);

    DECLARE z_Trip_Limit_Criteria_Changed int;
    DECLARE z_Trip_LOS_Code INT;

    DECLARE n_Notify_Days int;
    declare n_fred int;
    
    DECLARE CURSOR1 CURSOR FOR
       SELECT * FROM PRODUCTION.TRIP_LEG
          WHERE ((CALL_CENTER_CODE = P_CC_CODE) AND (DATE_OF_TRIP = P_DATE_OF_TRIP) AND (TRIP_ID = P_TRIP_ID) AND (TRIP_LEG = P_TRIP_LEG)) 
          FOR UPDATE WITH RS;

    DECLARE CURSOR2 CURSOR FOR
       SELECT PRESCHEDULE_CODE FROM PRODUCTION.TRIP
          WHERE ((CALL_CENTER_CODE = P_CC_CODE) AND (DATE_OF_TRIP = P_DATE_OF_TRIP) AND (TRIP_ID = P_TRIP_ID)) FOR READ ONLY;

    DECLARE CURSOR3 CURSOR FOR
       SELECT LOS_CODE,START_DATE,EXPIRE_DATE,Next_Date_Of_Trip,Updated_By,PRESCHED_DAYS_CODE,PCA,ADULT_ESCORTS,CHILD_ESCORTS,CARSEATS,TRIP_REASON_CODE,
          TREAT_TYPE_CODE,COMMENTS_FOR_TP,REQUESTED_BY,REQD_BY_PHONE,REQD_BY_PHONE_AC,REQD_BY_REL,GAS_REIMB_OP_CODE,GAS_REIMB_REL_CODE,
          TRIP_LOOKUP_A,TRIP_LOOKUP_B,TRIP_LOOKUP_C,TRIP_TEXT_A,TRIP_TEXT_B,TRIP_TEXT_C,TRIP_TEXT_D,TRIP_TEXT_E,STATUS,DIAGNOSTIC_CODE,
          AUTHORIZED_BY_CODE,LAST_DATE_OF_TRIP,NUMBER_OF_TRIPS,NUM_TRIPS_LEFT,HOLIDAY_CODE,REGION_CODE,Condition,Number_Trips_Verified,
          Expire_Reason_Code,Expire_Contact,Recertify_Date,Updated_On,
          PCA_CHG_APPROVED_BY, ADULT_ESC_CHG_APPROVED_BY, CHILD_ESC_CHG_APPROVED_BY,ORDERING_MED_PROV_NAME,ORDERING_MED_PROV_ID
          FROM PRODUCTION.PRESCHEDULE WHERE code = z_Preschedule_Code;

    DECLARE BC_Cursor Cursor for
       Select r.code,r.Broker_Client_Code,R.Rider_Type_Code,t.Treat_Type_Code,t.los_code
       from production.trip as t
       inner join production.rider as r on (t.rider_Code = r.code)
       where (t.call_Center_Code = p_CC_Code) and (t.Date_Of_Trip = p_Date_Of_Trip) and (t.trip_Id = p_Trip_ID);

    DECLARE Limit_Cursor CURSOR for
       SELECT Code,Trip_Limit_Type from table (Production.UDF_Trip_Limits(n_BC_Code,n_Rider_Type_Code,n_Treat_Type_Code,p_Date_Of_Trip,z_Trip_Los_Code,n_Miles)) as x;

    -- DECLARE HANDLER
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
       BEGIN
          GET DIAGNOSTICS EXCEPTION 1 MESSAGE_TEXT_OUT = MESSAGE_TEXT;
          SELECT SQLSTATE, SQLCODE INTO SQLSTATE_OUT, SQLCODE_OUT
              FROM SYSIBM.SYSDUMMY1;
          SET MESSAGE_TEXT_OUT = MESSAGE_TEXT_OUT || ' [IN P_UPDATE_TRIP_LEG]';
       END;

    DECLARE CONTINUE HANDLER FOR SQLWARNING
      set n_fred = 1;

    DECLARE CONTINUE HANDLER FOR NOT FOUND
      set n_fred = 1;

--    DECLARE EXIT HANDLER FOR SQLWARNING
--      BEGIN
--          GET DIAGNOSTICS EXCEPTION 1 MESSAGE_TEXT_OUT = MESSAGE_TEXT;
--          SELECT SQLSTATE, SQLCODE INTO SQLSTATE_OUT, SQLCODE_OUT
--             FROM SYSIBM.SYSDUMMY1;
--          SET MESSAGE_TEXT_OUT = MESSAGE_TEXT_OUT || ' [IN P_UPDATE_TRIP_LEG]';
--       END;

--    DECLARE EXIT HANDLER FOR NOT FOUND
--       BEGIN
--          GET DIAGNOSTICS EXCEPTION 1 MESSAGE_TEXT_OUT = MESSAGE_TEXT;
--          SELECT SQLSTATE, SQLCODE INTO SQLSTATE_OUT, SQLCODE_OUT
--            FROM SYSIBM.SYSDUMMY1;
--          SET MESSAGE_TEXT_OUT = MESSAGE_TEXT_OUT || ' [IN P_UPDATE_TRIP_LEG]';
--       END;

    -- IF P_USE_SUPPLIED_TS = 1
    --    THEN SET NOW = P_SUPPLIED_TIMESTAMP;
    --    ELSE SET NOW = production.udf_gmt();
    -- END IF;
    SET NOW = production.udf_gmt();

    OPEN CURSOR1;
    FETCH CURSOR1 INTO N_CC_CODE,N_DATE_OF_TRIP,N_TRIP_ID,N_TRIP_LEG,N_PU_ADDRESS_CODE,N_PU_APARTMENT,N_PU_PHONE_AC,N_PU_PHONE,N_PU_PHONE_EXT,
       N_PU_FACILITY_CODE,N_PU_TIME,N_DO_ADDRESS_CODE,N_DO_APARTMENT,N_DO_PHONE_AC,N_DO_PHONE,N_DO_PHONE_EXT,N_DO_FACILITY_CODE,N_DO_TIME,
       N_APPOINTMENT_TIME,N_TP_CODE,N_STATUS,N_UPDATED_BY,N_UPDATED_ON,N_MILES,N_COST,N_ACTUAL_PU_TIME,N_ACTUAL_DO_TIME,N_PU_BUILDING,N_DO_BUILDING,
       N_PU_DIRECTIONS,N_DO_DIRECTIONS,N_PU_PHYSICIAN,N_DO_PHYSICIAN,N_WILLCALL_RECVD,N_VEHICLE_CODE,N_COPAY,N_CANCEL_CODE,N_TP_OVERRIDE_CODE,
       N_ACTUAL_PU_ODOM,N_ACTUAL_DO_ODOM,N_PUBLIC_TRANSIT,N_TRIPLEG_LOOKUP_A,N_TRIPLEG_LOOKUP_B,N_TRIPLEG_LOOKUP_C,N_TRIP_LEG_TEXT_A,
       N_TRIP_LEG_TEXT_B,N_TRIP_LEG_TEXT_C,N_TRIP_LEG_TEXT_D,N_TRIP_LEG_TEXT_E,N_RECOVERY_USER_CODE,N_RECOVERY_STATE,
       N_COST_OVERRIDE,N_ESTIMATED_COST,N_PAID_LOS_CODE,N_BATCH_CODE,N_COPAY_COLLECTED,N_DRIVER_CODE,N_VOUCHER_NUMBER,
       N_TRANSFER,N_WAIT_HOURS,N_INCUR_WAIT_CHG,N_INCUR_ASSIST_CHG,N_RIDER_OCC_CODE,N_COST_OR_APPROVE_BY,N_CANCEL_SOURCE,
       N_INCUR_INCENTIVE,N_INCUR_DISCOUNT,N_INCUR_ADMIN_CHG,N_RIDER_SIGN_CODE,n_Verified_By,n_Verified_On,n_Miles_Override,n_Miles_OR_Approved_By,
       n_Total_Cost_Adjustments,n_Belongs_To_Call_Center_Code,
       n_Broker_Client_Code,n_Region_Code,
       n_SCHEDULED_WAIT_CHARGE, n_SCHEDULED_WAIT_TIME, n_SCHEDULED_ASSIST_CHARGE,
       n_WAIT_CHG_APPROVED_BY, n_ASSIST_CHG_APPROVED_BY, N_AML_UPDATED_ON,
       n_Requested_PU_Time,n_TP_Dispatched_Time,n_Billed_Cost, N_ASSISTANCE_TYPE_CODE,
       n_CLIENT_AUTH_NUMBER,n_OVERRIDE_COST,n_MASS_TRANSIT_OR_APPROVED_BY,n_MEDICAL_FORM_OR_APPROVED_BY,
       n_BILLED_COST_OR_APPROVED_BY,n_Spenddown           
       ;

--    IF (N_UPDATED_ON <> p_Last_Updated_On)        -- Caller read row before last update
    IF (production.udf_timestamp_ms(N_UPDATED_ON) <> production.udf_timestamp_ms(p_Last_Updated_On)) or (p_Last_Updated_On is null)        -- Caller read row before last update
       THEN SIGNAL SQLSTATE '75001' SET MESSAGE_TEXT = 'Last Update Timestamp is incorrect.';
    END IF;

    SELECT LOS_CODE,pca,adult_escorts,child_escorts into n_LOS_Code,n_pca,n_adult_escorts,n_child_Escorts from production.trip where (call_Center_Code = p_CC_Code and Date_of_trip = p_Date_of_Trip and trip_ID = p_Trip_ID);

    IF ((coalesce(P_MILES_STATUS,0) <> -1) or (p_PU_Address_Code <> n_PU_Address_Code) or (p_DO_Address_Code <> n_DO_Address_Code))
       THEN CALL LCADUSER.P_SET_ADDRESS_MILES(P_PU_ADDRESS_CODE,P_DO_ADDRESS_CODE,P_MILES,P_MILES_STATUS,P_USER_CODE,n_Region_Code,p_Address_Miles_Last_Miles_Source,p_AML_Updated_On,SQLSTATE_OUT,SQLCODE_OUT,MESSAGE_TEXT_OUT);
       -- ELSE IF (p_Miles_Override is NULL) or (n_Miles_Override is not null)
       ELSE IF (n_Miles_Override is not null)
          THEN SET p_AML_Updated_On = N_AML_UPDATED_ON;
          ELSE SET p_AML_Updated_On = NULL;
       END IF;
    END IF;

    if p_status < 0
       THEN SET p_Estimated_Cost = NULL;
    else
       if p_status = 6 or p_status = 7 -- do not recompute estimated cost on Verified_paid or Verified_denied
          THEN set n_fred = 1;
          else
          select copay,subtract_from_cost into n_BC_Copay_Copay,n_BC_Copay_Subtract_From_Cost 
             from production.bc_copay 
             where (n_Broker_Client_Code = broker_client_code and start_date <= p_date_of_trip and end_date > p_date_of_trip)
             ;
          
          if (coalesce(n_BC_Copay_Subtract_From_Cost,0) = 0)
             THEN SET n_Do_Copay_Subtract = 'N';
             ELSE SET n_Do_Copay_Subtract = 'Y';
          END IF;   
       
          IF (coalesce(n_Copay,-1) <> coalesce(n_BC_Copay_Copay,-1))
             THEN SET P_Copay = n_BC_Copay_Copay;
             ELSE SET p_Copay = n_Copay;
          END IF;
       

          if (Coalesce(n_PCA,0) > 0)
             THEN SET z_Incur_PCA_CHG = 'Y';
             else set z_Incur_PCA_CHG = 'N';
          END IF;

          if (Coalesce(n_Adult_Escorts,0) > 0)
             THEN SET z_Incur_ADULT_CHG = 'Y';
             else set z_Incur_ADULT_CHG = 'N';
          END IF;

          if (Coalesce(n_Child_Escorts,0) > 0)
             THEN SET z_Incur_CHILD_CHG = 'Y';
             else set z_Incur_CHILD_CHG = 'N';
          END IF;

          -- if (Coalesce(p_Scheduled_Wait_Charge,0) > 0)
          --    THEN SET z_Incur_WAIT_CHG = 'Y';
          --    else set z_Incur_WAIT_CHG = 'N';
          -- END IF;
          set z_Incur_WAIT_CHG = 'N';

          -- if (Coalesce(p_Scheduled_Assist_Charge,0) > 0)
          --    THEN SET z_Incur_ASSIST_CHG = 'Y';
          --    else set z_Incur_ASSIST_CHG = 'N';
          -- END IF;
          set z_Incur_ASSIST_CHG = 'N';

       -- Get Cost now call determine region for cost
       
          CALL LCADUSER.P_GET_COST(n_Broker_Client_Code,p_PU_ADDRESS_CODE,p_DO_ADDRESS_CODE,
             n_Region_Code,P_TP_Code,N_LOS_Code,P_DATE_OF_TRIP,coalesce(TIME(P_PU_TIME),TIME('12:00:00')),p_Miles,
             z_Incur_Wait_CHG,z_Incur_Assist_CHG,z_Incur_PCA_CHG,z_Incur_Adult_CHG,z_Incur_Child_CHG,
             'N',n_Do_Copay_Subtract,'N','N',N_PCA,N_ADULT_ESCORTS,N_CHILD_ESCORTS,
             N_COPAY, -- P_COPAY, change to N_COPAY
             n_Scheduled_Wait_Time, -- p_Scheduled_Wait_Time,
             0,0,p_PUBLIC_TRANSIT,A_Actual_Cost_Calc,
             A_FFS_Cost_Calc,A_Rate_Code,A_Rate_Found,
             a_PCA_Rate,a_Adult_Escorts_Rate,a_Child_Escorts_Rate, 
             a_Wait_Rate,a_Assist_Rate,a_used_Master_Rate,
             SQLSTATE_OUT,SQLCODE_OUT,MESSAGE_TEXT_OUT);

          IF a_Rate_Found = 1 and (coalesce(SQLSTATE_OUT,'00000') = '00000')
             THEN set p_Estimated_Cost = a_Actual_Cost_Calc;
          else set p_Estimated_Cost = NULL;
          END IF;
       END IF;
    END IF;

    SET z_Verified_By = n_Verified_By;
    set z_Verified_On = n_Verified_On;

    IF (N_STATUS = 5) and (z_Verified_On is not null) and ((P_STATUS IS NULL) OR (P_STATUS <> 5)) -- Being set from Verified and already set
       THEN
          SET z_Verified_By = NULL;
          set z_Verified_On = NULL;
    END IF;

    IF (P_STATUS = 6) and ((N_STATUS IS NULL) OR (N_STATUS <> 6))  -- Being set to Verified Paid
       THEN
          SET z_Verified_By = p_User_Code;
          set z_Verified_On = now;
       --ELSE
          --SET z_Verified_By = n_Verified_By;
          --set z_Verified_On = n_Verified_On;
    END IF;

    IF (N_STATUS = 6) and ((P_STATUS IS NULL) OR (P_STATUS <> 6)) -- Being set from Verified Paid
       THEN
          SET z_Verified_By = NULL;
          set z_Verified_On = NULL;
       --ELSE
          --SET z_Verified_By = n_Verified_By;
          --set z_Verified_On = n_Verified_On;
    END IF;

    UPDATE PRODUCTION.TRIP_LEG SET (PU_ADDRESS_CODE,PU_APARTMENT,PU_PHONE_AC,PU_PHONE,
        -- PU_PHONE_EXT,
        PU_FACILITY_CODE,PU_TIME,DO_ADDRESS_CODE,DO_APARTMENT,DO_PHONE_AC,DO_PHONE,
        -- DO_PHONE_EXT,
        DO_FACILITY_CODE,DO_TIME,APPOINTMENT_TIME,
        TP_CODE,STATUS,UPDATED_BY,UPDATED_ON,MILES,
        -- COST,
        -- ACTUAL_PU_TIME,ACTUAL_DO_TIME,
        PU_BUILDING,
        DO_BUILDING,PU_DIRECTIONS,DO_DIRECTIONS,
        -- PU_PHYSICIAN,DO_PHYSICIAN,
        -- WILLCALL_RECVD,
        -- VEHICLE_CODE,
        -- COPAY,
        CANCELLATION_CODE,
        -- TP_OVERRIDE_CODE,
        -- ACTUAL_PU_ODOMETER,ACTUAL_DO_ODOMETER,
        -- PUBLIC_TRANSIT,
        -- TRIP_LEG_LOOKUP_A,TRIP_LEG_LOOKUP_B,TRIP_LEG_LOOKUP_C,
        -- TRIP_LEG_TEXT_A,TRIP_LEG_TEXT_B,TRIP_LEG_TEXT_C,TRIP_LEG_TEXT_D,TRIP_LEG_TEXT_E,
        -- RECOVERY_USER_CODE,RECOVERY_STATE,
        -- COST_OVERRIDE,
        ESTIMATED_COST,
        -- PAID_LOS_CODE,
        -- BATCH_CODE,
        -- COPAY_COLLECTED,
        -- DRIVER_CODE,
        -- VOUCHER_NUMBER,
        -- TRANSFER,
        -- WAIT_HOURS,
        -- INCUR_WAIT_CHG,
        -- INCUR_ASSIST_CHG,
        -- RIDER_OCC_CODE,
        -- COST_OR_APPROVE_BY,
        CANCEL_SOURCE,
        -- INCUR_INCENTIVE,INCUR_DISCOUNT,INCUR_ADMIN_CHG,
        -- RIDER_SIGN_CODE,
        Verified_By,Verified_On,
        -- miles_Override,miles_OR_Approved_By,
        -- Total_Cost_Adjustments,
        -- SCHEDULED_WAIT_CHARGE, SCHEDULED_WAIT_TIME, SCHEDULED_ASSIST_CHARGE,
        -- WAIT_CHG_APPROVED_BY, ASSIST_CHG_APPROVED_BY,
        AML_Updated_On,
        -- Requested_PU_Time,
        -- TP_Dispatched_Time,
        -- Billed_Cost,
        ASSISTANCE_TYPE_CODE
        -- CLIENT_AUTH_NUMBER,
        -- OVERRIDE_COST,
        -- MASS_TRANSIT_OR_APPROVED_BY,
        -- MEDICAL_FORM_OR_APPROVED_BY,
        -- BILLED_COST_OR_APPROVED_BY,
        -- SPENDDOWN 
        ) 
        =
        (P_PU_ADDRESS_CODE,P_PU_APARTMENT,P_PU_PHONE_AC,P_PU_PHONE,
        -- P_PU_PHONE_EXT,
        P_PU_FACILITY_CODE,P_PU_TIME,P_DO_ADDRESS_CODE,P_DO_APARTMENT,P_DO_PHONE_AC,P_DO_PHONE,
        -- P_DO_PHONE_EXT,
        P_DO_FACILITY_CODE,P_DO_TIME,P_APPOINTMENT_TIME,
        P_TP_CODE,P_STATUS,P_USER_CODE,NOW,P_MILES,
        -- P_COST,
        -- P_ACTUAL_PU_TIME,P_ACTUAL_DO_TIME,
        P_PU_BUILDING,
        P_DO_BUILDING,P_PU_DIRECTIONS,P_DO_DIRECTIONS,
        -- P_PU_PHYSICIAN,P_DO_PHYSICIAN,
        -- P_WILLCALL_RECVD,
        -- P_VEHICLE_CODE,
        -- P_COPAY,
        P_CANCEL_CODE,
        -- P_TP_OVERRIDE_CODE,
        -- P_ACTUAL_PU_ODOM,P_ACTUAL_DO_ODOM,
        -- P_PUBLIC_TRANSIT,
        -- P_TRIPLEG_LOOKUP_A,P_TRIPLEG_LOOKUP_B,P_TRIPLEG_LOOKUP_C,
        -- P_TRIP_LEG_TEXT_A,P_TRIP_LEG_TEXT_B,P_TRIP_LEG_TEXT_C,P_TRIP_LEG_TEXT_D,P_TRIP_LEG_TEXT_E,
        -- P_RECOVERY_USER_CODE,P_RECOVERY_STATE,
        -- P_COST_OVERRIDE,
        P_ESTIMATED_COST,
        -- P_PAID_LOS_CODE,
        -- P_BATCH_CODE,
        -- P_COPAY_COLLECTED,
        -- P_DRIVER_CODE,
        -- P_VOUCHER_NUMBER,
        -- P_TRANSFER,
        -- P_WAIT_HOURS,
        -- P_INCUR_WAIT_CHG,
        -- P_INCUR_ASSIST_CHG,
        -- P_RIDER_OCC_CODE,
        -- P_COST_OR_APPROVE_BY,
        P_CANCEL_SOURCE,
        -- P_INCUR_INCENTIVE,P_INCUR_DISCOUNT,P_INCUR_ADMIN_CHG,
        -- P_RIDER_SIGN_CODE,
        z_Verified_By,z_Verified_On,
        -- p_Miles_Override,p_Miles_OR_Approved_By,
        -- p_Total_Cost_Adjustments,
        -- p_SCHEDULED_WAIT_CHARGE, p_SCHEDULED_WAIT_TIME, p_SCHEDULED_ASSIST_CHARGE,
        -- p_WAIT_CHG_APPROVED_BY, p_ASSIST_CHG_APPROVED_BY,
        p_AML_Updated_On,
        -- p_Requested_PU_Time,
        -- p_TP_Dispatched_Time,
        -- p_Billed_Cost, 
        P_ASSISTANCE_TYPE_CODE
        -- p_CLIENT_AUTH_NUMBER,
        -- P_OVERRIDE_COST,
        -- p_MASS_TRANSIT_OR_APPROVED_BY,
        -- p_MEDICAL_FORM_OR_APPROVED_BY,
        -- p_BILLED_COST_OR_APPROVED_BY,
        -- p_Spenddown     
        )
        WHERE ((CALL_CENTER_CODE = P_CC_CODE) AND (DATE_OF_TRIP = P_DATE_OF_TRIP) AND (TRIP_ID = P_TRIP_ID) AND (TRIP_LEG = P_TRIP_LEG));

    SET z_Trip_Limit_Criteria_Changed = 0;
    set x_Something_Changed = 0;
    IF ((P_PU_ADDRESS_CODE <> N_PU_ADDRESS_CODE) OR ((P_PU_ADDRESS_CODE IS NULL) AND (N_PU_ADDRESS_CODE IS NOT NULL)) OR
       ((P_PU_ADDRESS_CODE IS NOT NULL) AND (N_PU_ADDRESS_CODE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_ADDRESS_CODE',RTRIM(CAST(N_PU_ADDRESS_CODE AS CHAR(250))),RTRIM(CAST(P_PU_ADDRESS_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_PU_APARTMENT <> N_PU_APARTMENT) OR ((P_PU_APARTMENT IS NULL) AND (N_PU_APARTMENT IS NOT NULL)) OR
       ((P_PU_APARTMENT IS NOT NULL) AND (N_PU_APARTMENT IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_APARTMENT',RTRIM(CAST(N_PU_APARTMENT AS CHAR(250))),RTRIM(CAST(P_PU_APARTMENT  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_PU_PHONE_AC <> N_PU_PHONE_AC) OR ((P_PU_PHONE_AC IS NULL) AND (N_PU_PHONE_AC IS NOT NULL)) OR
       ((P_PU_PHONE_AC IS NOT NULL) AND (N_PU_PHONE_AC IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_PHONE_AC',RTRIM(CAST(N_PU_PHONE_AC AS CHAR(250))),RTRIM(CAST(P_PU_PHONE_AC  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_PU_PHONE <> N_PU_PHONE) OR ((P_PU_PHONE IS NULL) AND (N_PU_PHONE IS NOT NULL)) OR
       ((P_PU_PHONE IS NOT NULL) AND (N_PU_PHONE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_PHONE',RTRIM(CAST(N_PU_PHONE AS CHAR(250))),RTRIM(CAST(P_PU_PHONE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    -- IF ((P_PU_PHONE_EXT <> N_PU_PHONE_EXT) OR ((P_PU_PHONE_EXT IS NULL) AND (N_PU_PHONE_EXT IS NOT NULL)) OR
    --    ((P_PU_PHONE_EXT IS NOT NULL) AND (N_PU_PHONE_EXT IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_PHONE_EXT',RTRIM(CAST(N_PU_PHONE_EXT AS CHAR(250))),RTRIM(CAST(P_PU_PHONE_EXT  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    IF ((P_PU_FACILITY_CODE <> N_PU_FACILITY_CODE) OR ((P_PU_FACILITY_CODE IS NULL) AND (N_PU_FACILITY_CODE IS NOT NULL)) OR
       ((P_PU_FACILITY_CODE IS NOT NULL) AND (N_PU_FACILITY_CODE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_FACILITY_CODE',RTRIM(CAST(N_PU_FACILITY_CODE AS CHAR(250))),RTRIM(CAST(P_PU_FACILITY_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_PU_TIME <> N_PU_TIME) OR ((P_PU_TIME IS NULL) AND (N_PU_TIME IS NOT NULL)) OR
       ((P_PU_TIME IS NOT NULL) AND (N_PU_TIME IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_TIME',RTRIM(CAST(N_PU_TIME AS CHAR(250))),RTRIM(CAST(P_PU_TIME  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_DO_ADDRESS_CODE <> N_DO_ADDRESS_CODE) OR ((P_DO_ADDRESS_CODE IS NULL) AND (N_DO_ADDRESS_CODE IS NOT NULL)) OR
       ((P_DO_ADDRESS_CODE IS NOT NULL) AND (N_DO_ADDRESS_CODE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_ADDRESS_CODE',RTRIM(CAST(N_DO_ADDRESS_CODE AS CHAR(250))),RTRIM(CAST(P_DO_ADDRESS_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_DO_APARTMENT <> N_DO_APARTMENT) OR ((P_DO_APARTMENT IS NULL) AND (N_DO_APARTMENT IS NOT NULL)) OR
       ((P_DO_APARTMENT IS NOT NULL) AND (N_DO_APARTMENT IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_APARTMENT',RTRIM(CAST(N_DO_APARTMENT AS CHAR(250))),RTRIM(CAST(P_DO_APARTMENT  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_DO_PHONE_AC <> N_DO_PHONE_AC) OR ((P_DO_PHONE_AC IS NULL) AND (N_DO_PHONE_AC IS NOT NULL)) OR
       ((P_DO_PHONE_AC IS NOT NULL) AND (N_DO_PHONE_AC IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_PHONE_AC',RTRIM(CAST(N_DO_PHONE_AC AS CHAR(250))),RTRIM(CAST(P_DO_PHONE_AC  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_DO_PHONE <> N_DO_PHONE) OR ((P_DO_PHONE IS NULL) AND (N_DO_PHONE IS NOT NULL)) OR
       ((P_DO_PHONE IS NOT NULL) AND (N_DO_PHONE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_PHONE',RTRIM(CAST(N_DO_PHONE AS CHAR(250))),RTRIM(CAST(P_DO_PHONE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    -- IF ((P_DO_PHONE_EXT <> N_DO_PHONE_EXT) OR ((P_DO_PHONE_EXT IS NULL) AND (N_DO_PHONE_EXT IS NOT NULL)) OR
    --    ((P_DO_PHONE_EXT IS NOT NULL) AND (N_DO_PHONE_EXT IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_PHONE_EXT',RTRIM(CAST(N_DO_PHONE_EXT AS CHAR(250))),RTRIM(CAST(P_DO_PHONE_EXT  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    IF ((P_DO_FACILITY_CODE <> N_DO_FACILITY_CODE) OR ((P_DO_FACILITY_CODE IS NULL) AND (N_DO_FACILITY_CODE IS NOT NULL)) OR
       ((P_DO_FACILITY_CODE IS NOT NULL) AND (N_DO_FACILITY_CODE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_FACILITY_CODE',RTRIM(CAST(N_DO_FACILITY_CODE AS CHAR(250))),RTRIM(CAST(P_DO_FACILITY_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_DO_TIME <> N_DO_TIME) OR ((P_DO_TIME IS NULL) AND (N_DO_TIME IS NOT NULL)) OR
       ((P_DO_TIME IS NOT NULL) AND (N_DO_TIME IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_TIME',RTRIM(CAST(N_DO_TIME AS CHAR(250))),RTRIM(CAST(P_DO_TIME  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_APPOINTMENT_TIME <> N_APPOINTMENT_TIME) OR ((P_APPOINTMENT_TIME IS NULL) AND (N_APPOINTMENT_TIME IS NOT NULL)) OR
       ((P_APPOINTMENT_TIME IS NOT NULL) AND (N_APPOINTMENT_TIME IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'APPOINTMENT_TIME',RTRIM(CAST(N_APPOINTMENT_TIME AS CHAR(250))),RTRIM(CAST(P_APPOINTMENT_TIME  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_TP_CODE <> N_TP_CODE) OR ((P_TP_CODE IS NULL) AND (N_TP_CODE IS NOT NULL)) OR
       ((P_TP_CODE IS NOT NULL) AND (N_TP_CODE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TP_CODE',RTRIM(CAST(N_TP_CODE AS CHAR(250))),RTRIM(CAST(P_TP_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_STATUS <> N_STATUS) OR ((P_STATUS IS NULL) AND (N_STATUS IS NOT NULL)) OR
       ((P_STATUS IS NOT NULL) AND (N_STATUS IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'STATUS',RTRIM(CAST(N_STATUS AS CHAR(250))),RTRIM(CAST(P_STATUS  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_MILES <> N_MILES) OR ((P_MILES IS NULL) AND (N_MILES IS NOT NULL)) OR
       ((P_MILES IS NOT NULL) AND (N_MILES IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'MILES',RTRIM(CAST(N_MILES AS CHAR(250))),RTRIM(CAST(P_MILES  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
          SET z_Trip_Limit_Criteria_Changed = 1;
    END IF;

    -- IF ((P_COST <> N_COST) OR ((P_COST IS NULL) AND (N_COST IS NOT NULL)) OR
    --    ((P_COST IS NOT NULL) AND (N_COST IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'COST',RTRIM(CAST(N_COST AS CHAR(250))),RTRIM(CAST(P_COST  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_ACTUAL_PU_TIME <> N_ACTUAL_PU_TIME) OR ((P_ACTUAL_PU_TIME IS NULL) AND (N_ACTUAL_PU_TIME IS NOT NULL)) OR
    --    ((P_ACTUAL_PU_TIME IS NOT NULL) AND (N_ACTUAL_PU_TIME IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'ACTUAL_PU_TIME',RTRIM(CAST(N_ACTUAL_PU_TIME AS CHAR(250))),RTRIM(CAST(P_ACTUAL_PU_TIME  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_ACTUAL_DO_TIME <> N_ACTUAL_DO_TIME) OR ((P_ACTUAL_DO_TIME IS NULL) AND (N_ACTUAL_DO_TIME IS NOT NULL)) OR
    --    ((P_ACTUAL_DO_TIME IS NOT NULL) AND (N_ACTUAL_DO_TIME IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'ACTUAL_DO_TIME',RTRIM(CAST(N_ACTUAL_DO_TIME AS CHAR(250))),RTRIM(CAST(P_ACTUAL_DO_TIME  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    IF ((P_PU_BUILDING <> N_PU_BUILDING) OR ((P_PU_BUILDING IS NULL) AND (N_PU_BUILDING IS NOT NULL)) OR
       ((P_PU_BUILDING IS NOT NULL) AND (N_PU_BUILDING IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_BUILDING',RTRIM(CAST(N_PU_BUILDING AS CHAR(250))),RTRIM(CAST(P_PU_BUILDING  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_DO_BUILDING <> N_DO_BUILDING) OR ((P_DO_BUILDING IS NULL) AND (N_DO_BUILDING IS NOT NULL)) OR
       ((P_DO_BUILDING IS NOT NULL) AND (N_DO_BUILDING IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_BUILDING',RTRIM(CAST(N_DO_BUILDING AS CHAR(250))),RTRIM(CAST(P_DO_BUILDING  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_PU_DIRECTIONS <> N_PU_DIRECTIONS) OR ((P_PU_DIRECTIONS IS NULL) AND (N_PU_DIRECTIONS IS NOT NULL)) OR
       ((P_PU_DIRECTIONS IS NOT NULL) AND (N_PU_DIRECTIONS IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_DIRECTIONS',RTRIM(CAST(N_PU_DIRECTIONS AS CHAR(250))),RTRIM(CAST(P_PU_DIRECTIONS  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    IF ((P_DO_DIRECTIONS <> N_DO_DIRECTIONS) OR ((P_DO_DIRECTIONS IS NULL) AND (N_DO_DIRECTIONS IS NOT NULL)) OR
       ((P_DO_DIRECTIONS IS NOT NULL) AND (N_DO_DIRECTIONS IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_DIRECTIONS',RTRIM(CAST(N_DO_DIRECTIONS AS CHAR(250))),RTRIM(CAST(P_DO_DIRECTIONS  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    -- IF ((P_PU_PHYSICIAN <> N_PU_PHYSICIAN) OR ((P_PU_PHYSICIAN IS NULL) AND (N_PU_PHYSICIAN IS NOT NULL)) OR
    --    ((P_PU_PHYSICIAN IS NOT NULL) AND (N_PU_PHYSICIAN IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PU_PHYSICIAN',RTRIM(CAST(N_PU_PHYSICIAN AS CHAR(250))),RTRIM(CAST(P_PU_PHYSICIAN  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_DO_PHYSICIAN <> N_DO_PHYSICIAN) OR ((P_DO_PHYSICIAN IS NULL) AND (N_DO_PHYSICIAN IS NOT NULL)) OR
    --    ((P_DO_PHYSICIAN IS NOT NULL) AND (N_DO_PHYSICIAN IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DO_PHYSICIAN',RTRIM(CAST(N_DO_PHYSICIAN AS CHAR(250))),RTRIM(CAST(P_DO_PHYSICIAN  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_WILLCALL_RECVD <> N_WILLCALL_RECVD) OR ((P_WILLCALL_RECVD IS NULL) AND (N_WILLCALL_RECVD IS NOT NULL)) OR
    --    ((P_WILLCALL_RECVD IS NOT NULL) AND (N_WILLCALL_RECVD IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'WILLCALL_RECVD',RTRIM(CAST(N_WILLCALL_RECVD AS CHAR(250))),RTRIM(CAST(P_WILLCALL_RECVD  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_VEHICLE_CODE <> N_VEHICLE_CODE) OR ((P_VEHICLE_CODE IS NULL) AND (N_VEHICLE_CODE IS NOT NULL)) OR
    --    ((P_VEHICLE_CODE IS NOT NULL) AND (N_VEHICLE_CODE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'VEHICLE_CODE',RTRIM(CAST(N_VEHICLE_CODE AS CHAR(250))),RTRIM(CAST(P_VEHICLE_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_COPAY <> N_COPAY) OR ((P_COPAY IS NULL) AND (N_COPAY IS NOT NULL)) OR
    --    ((P_COPAY IS NOT NULL) AND (N_COPAY IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'COPAY',RTRIM(CAST(N_COPAY AS CHAR(250))),RTRIM(CAST(P_COPAY  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    IF ((P_CANCEL_CODE <> N_CANCEL_CODE) OR ((P_CANCEL_CODE IS NULL) AND (N_CANCEL_CODE IS NOT NULL)) OR
       ((P_CANCEL_CODE IS NOT NULL) AND (N_CANCEL_CODE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'CANCELLATION_CODE',RTRIM(CAST(N_CANCEL_CODE AS CHAR(250))),RTRIM(CAST(P_CANCEL_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    -- IF ((P_TP_OVERRIDE_CODE <> N_TP_OVERRIDE_CODE) OR ((P_TP_OVERRIDE_CODE IS NULL) AND (N_TP_OVERRIDE_CODE IS NOT NULL)) OR
    --    ((P_TP_OVERRIDE_CODE IS NOT NULL) AND (N_TP_OVERRIDE_CODE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TP_OVERRIDE_CODE',RTRIM(CAST(N_TP_OVERRIDE_CODE AS CHAR(250))),RTRIM(CAST(P_TP_OVERRIDE_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_ACTUAL_PU_ODOM <> N_ACTUAL_PU_ODOM) OR ((P_ACTUAL_PU_ODOM IS NULL) AND (N_ACTUAL_PU_ODOM IS NOT NULL)) OR
    --    ((P_ACTUAL_PU_ODOM IS NOT NULL) AND (N_ACTUAL_PU_ODOM IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'ACTUAL_PU_ODOMETER',RTRIM(CAST(N_ACTUAL_PU_ODOM AS CHAR(250))),RTRIM(CAST(P_ACTUAL_PU_ODOM  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_ACTUAL_DO_ODOM <> N_ACTUAL_DO_ODOM) OR ((P_ACTUAL_DO_ODOM IS NULL) AND (N_ACTUAL_DO_ODOM IS NOT NULL)) OR
    --    ((P_ACTUAL_DO_ODOM IS NOT NULL) AND (N_ACTUAL_DO_ODOM IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'ACTUAL_DO_ODOMETER',RTRIM(CAST(N_ACTUAL_DO_ODOM AS CHAR(250))),RTRIM(CAST(P_ACTUAL_DO_ODOM  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_PUBLIC_TRANSIT <> N_PUBLIC_TRANSIT) OR ((P_PUBLIC_TRANSIT IS NULL) AND (N_PUBLIC_TRANSIT IS NOT NULL)) OR
    --    ((P_PUBLIC_TRANSIT IS NOT NULL) AND (N_PUBLIC_TRANSIT IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PUBLIC_TRANSIT',RTRIM(CAST(N_PUBLIC_TRANSIT AS CHAR(250))),RTRIM(CAST(P_PUBLIC_TRANSIT  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRIPLEG_LOOKUP_A <> N_TRIPLEG_LOOKUP_A) OR ((P_TRIPLEG_LOOKUP_A IS NULL) AND (N_TRIPLEG_LOOKUP_A IS NOT NULL)) OR
    --    ((P_TRIPLEG_LOOKUP_A IS NOT NULL) AND (N_TRIPLEG_LOOKUP_A IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRIP_LEG_LOOKUP_A',RTRIM(CAST(N_TRIPLEG_LOOKUP_A AS CHAR(250))),RTRIM(CAST(P_TRIPLEG_LOOKUP_A  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRIPLEG_LOOKUP_B <> N_TRIPLEG_LOOKUP_B) OR ((P_TRIPLEG_LOOKUP_B IS NULL) AND (N_TRIPLEG_LOOKUP_B IS NOT NULL)) OR
    --    ((P_TRIPLEG_LOOKUP_B IS NOT NULL) AND (N_TRIPLEG_LOOKUP_B IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRIP_LEG_LOOKUP_B',RTRIM(CAST(N_TRIPLEG_LOOKUP_B AS CHAR(250))),RTRIM(CAST(P_TRIPLEG_LOOKUP_B  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRIPLEG_LOOKUP_C <> N_TRIPLEG_LOOKUP_C) OR ((P_TRIPLEG_LOOKUP_C IS NULL) AND (N_TRIPLEG_LOOKUP_C IS NOT NULL)) OR
    --    ((P_TRIPLEG_LOOKUP_C IS NOT NULL) AND (N_TRIPLEG_LOOKUP_C IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRIP_LEG_LOOKUP_C',RTRIM(CAST(N_TRIPLEG_LOOKUP_C AS CHAR(250))),RTRIM(CAST(P_TRIPLEG_LOOKUP_C  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRIP_LEG_TEXT_A <> N_TRIP_LEG_TEXT_A) OR ((P_TRIP_LEG_TEXT_A IS NULL) AND (N_TRIP_LEG_TEXT_A IS NOT NULL)) OR
    --    ((P_TRIP_LEG_TEXT_A IS NOT NULL) AND (N_TRIP_LEG_TEXT_A IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRIP_LEG_TEXT_A',RTRIM(CAST(N_TRIP_LEG_TEXT_A AS CHAR(250))),RTRIM(CAST(P_TRIP_LEG_TEXT_A  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRIP_LEG_TEXT_B <> N_TRIP_LEG_TEXT_B) OR ((P_TRIP_LEG_TEXT_B IS NULL) AND (N_TRIP_LEG_TEXT_B IS NOT NULL)) OR
    --    ((P_TRIP_LEG_TEXT_B IS NOT NULL) AND (N_TRIP_LEG_TEXT_B IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRIP_LEG_TEXT_B',RTRIM(CAST(N_TRIP_LEG_TEXT_B AS CHAR(250))),RTRIM(CAST(P_TRIP_LEG_TEXT_B  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRIP_LEG_TEXT_C <> N_TRIP_LEG_TEXT_C) OR ((P_TRIP_LEG_TEXT_C IS NULL) AND (N_TRIP_LEG_TEXT_C IS NOT NULL)) OR
    --    ((P_TRIP_LEG_TEXT_C IS NOT NULL) AND (N_TRIP_LEG_TEXT_C IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRIP_LEG_TEXT_C',RTRIM(CAST(N_TRIP_LEG_TEXT_C AS CHAR(250))),RTRIM(CAST(P_TRIP_LEG_TEXT_C  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRIP_LEG_TEXT_D <> N_TRIP_LEG_TEXT_D) OR ((P_TRIP_LEG_TEXT_D IS NULL) AND (N_TRIP_LEG_TEXT_D IS NOT NULL)) OR
    --    ((P_TRIP_LEG_TEXT_D IS NOT NULL) AND (N_TRIP_LEG_TEXT_D IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRIP_LEG_TEXT_D',RTRIM(CAST(N_TRIP_LEG_TEXT_D AS CHAR(250))),RTRIM(CAST(P_TRIP_LEG_TEXT_D  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRIP_LEG_TEXT_E <> N_TRIP_LEG_TEXT_E) OR ((P_TRIP_LEG_TEXT_E IS NULL) AND (N_TRIP_LEG_TEXT_E IS NOT NULL)) OR
    --    ((P_TRIP_LEG_TEXT_E IS NOT NULL) AND (N_TRIP_LEG_TEXT_E IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRIP_LEG_TEXT_E',RTRIM(CAST(N_TRIP_LEG_TEXT_E AS CHAR(250))),RTRIM(CAST(P_TRIP_LEG_TEXT_E  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_RECOVERY_USER_CODE <> N_RECOVERY_USER_CODE) OR ((P_RECOVERY_USER_CODE IS NULL) AND (N_RECOVERY_USER_CODE IS NOT NULL)) OR
    --    ((P_RECOVERY_USER_CODE IS NOT NULL) AND (N_RECOVERY_USER_CODE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'RECOVERY_USER_CODE',RTRIM(CAST(N_RECOVERY_USER_CODE AS CHAR(250))),RTRIM(CAST(P_RECOVERY_USER_CODE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_RECOVERY_STATE <> N_RECOVERY_STATE) OR ((P_RECOVERY_STATE IS NULL) AND (N_RECOVERY_STATE IS NOT NULL)) OR
    --    ((P_RECOVERY_STATE IS NOT NULL) AND (N_RECOVERY_STATE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'RECOVERY_STATE',RTRIM(CAST(N_RECOVERY_STATE AS CHAR(250))),RTRIM(CAST(P_RECOVERY_STATE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_COST_OVERRIDE <> N_COST_OVERRIDE) OR ((P_COST_OVERRIDE IS NULL) AND (N_COST_OVERRIDE IS NOT NULL)) OR
    --    ((P_COST_OVERRIDE IS NOT NULL) AND (N_COST_OVERRIDE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'COST_OVERRIDE',RTRIM(CAST(N_COST_OVERRIDE AS CHAR(250))),RTRIM(CAST(P_COST_OVERRIDE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    IF ((P_ESTIMATED_COST <> N_ESTIMATED_COST) OR ((P_ESTIMATED_COST IS NULL) AND (N_ESTIMATED_COST IS NOT NULL)) OR
       ((P_ESTIMATED_COST IS NOT NULL) AND (N_ESTIMATED_COST IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'ESTIMATED_COST',RTRIM(CAST(N_ESTIMATED_COST AS CHAR(250))),RTRIM(CAST(P_ESTIMATED_COST  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    -- IF ((P_PAID_LOS_CODE <> N_PAID_LOS_CODE) OR ((P_PAID_LOS_CODE IS NULL) AND (N_PAID_LOS_CODE IS NOT NULL)) OR
    --    ((P_PAID_LOS_CODE IS NOT NULL) AND (N_PAID_LOS_CODE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'PAID_LOS_CODE',RTRIM(CAST(N_PAID_LOS_CODE AS CHAR(250))),RTRIM(CAST(P_PAID_LOS_CODE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_BATCH_CODE <> N_BATCH_CODE) OR ((P_BATCH_CODE IS NULL) AND (N_BATCH_CODE IS NOT NULL)) OR
    --    ((P_BATCH_CODE IS NOT NULL) AND (N_BATCH_CODE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'BATCH_CODE',RTRIM(CAST(N_BATCH_CODE AS CHAR(250))),RTRIM(CAST(P_BATCH_CODE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_COPAY_COLLECTED <> N_COPAY_COLLECTED) OR (( P_COPAY_COLLECTED IS NULL) AND (N_COPAY_COLLECTED IS NOT NULL)) OR
    --    (( P_COPAY_COLLECTED IS NOT NULL) AND (N_COPAY_COLLECTED IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'COPAY_COLLECTED',RTRIM(CAST(N_COPAY_COLLECTED AS CHAR(250))),RTRIM(CAST(P_COPAY_COLLECTED  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_DRIVER_CODE <> N_DRIVER_CODE) OR ((P_DRIVER_CODE IS NULL) AND (N_DRIVER_CODE IS NOT NULL)) OR
    --    ((P_DRIVER_CODE IS NOT NULL) AND (N_DRIVER_CODE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'DRIVER_CODE',RTRIM(CAST(N_DRIVER_CODE AS CHAR(250))),RTRIM(CAST(P_DRIVER_CODE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_VOUCHER_NUMBER <> N_VOUCHER_NUMBER) OR ((P_VOUCHER_NUMBER IS NULL) AND (N_VOUCHER_NUMBER IS NOT NULL)) OR
    --    ((P_VOUCHER_NUMBER IS NOT NULL) AND (N_VOUCHER_NUMBER IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'VOUCHER_NUMBER',RTRIM(CAST(N_VOUCHER_NUMBER AS CHAR(250))),RTRIM(CAST(P_VOUCHER_NUMBER AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_TRANSFER <> N_TRANSFER) OR ((P_TRANSFER IS NULL) AND (N_TRANSFER IS NOT NULL)) OR
    --    ((P_TRANSFER IS NOT NULL) AND (N_TRANSFER IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TRANSFER',RTRIM(CAST(N_TRANSFER AS CHAR(250))),RTRIM(CAST(P_TRANSFER AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_WAIT_HOURS <> N_WAIT_HOURS) OR ((P_WAIT_HOURS IS NULL) AND (N_WAIT_HOURS IS NOT NULL)) OR
    --    ((P_WAIT_HOURS IS NOT NULL) AND (N_WAIT_HOURS IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'WAIT_HOURS',RTRIM(CAST(N_WAIT_HOURS AS CHAR(250))),RTRIM(CAST(P_WAIT_HOURS AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_INCUR_WAIT_CHG <> N_INCUR_WAIT_CHG) OR ((P_INCUR_WAIT_CHG IS NULL) AND (N_INCUR_WAIT_CHG IS NOT NULL)) OR
    --    ((P_INCUR_WAIT_CHG IS NOT NULL) AND (N_INCUR_WAIT_CHG IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'INCUR_WAIT_CHG',RTRIM(CAST(N_INCUR_WAIT_CHG AS CHAR(250))),RTRIM(CAST(P_INCUR_WAIT_CHG AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_INCUR_ASSIST_CHG <> N_INCUR_ASSIST_CHG) OR ((P_INCUR_ASSIST_CHG IS NULL) AND (N_INCUR_ASSIST_CHG IS NOT NULL)) OR
    --    ((P_INCUR_ASSIST_CHG IS NOT NULL) AND (N_INCUR_ASSIST_CHG IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'INCUR_ASSIST_CHG',RTRIM(CAST(N_INCUR_ASSIST_CHG AS CHAR(250))),RTRIM(CAST(P_INCUR_ASSIST_CHG AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_RIDER_OCC_CODE <> N_RIDER_OCC_CODE) OR ((P_RIDER_OCC_CODE IS NULL) AND (N_RIDER_OCC_CODE IS NOT NULL)) OR
    --    ((P_RIDER_OCC_CODE IS NOT NULL) AND (N_RIDER_OCC_CODE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'RIDER_OCC_CODE',RTRIM(CAST(N_RIDER_OCC_CODE AS CHAR(250))),RTRIM(CAST(P_RIDER_OCC_CODE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_COST_OR_APPROVE_BY <> N_COST_OR_APPROVE_BY) OR ((P_COST_OR_APPROVE_BY IS NULL) AND (N_COST_OR_APPROVE_BY IS NOT NULL)) OR
    --    ((P_COST_OR_APPROVE_BY IS NOT NULL) AND (N_COST_OR_APPROVE_BY IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'COST_OR_APPROVE_BY',RTRIM(CAST(N_COST_OR_APPROVE_BY AS CHAR(250))),RTRIM(CAST(P_COST_OR_APPROVE_BY  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    IF ((P_CANCEL_SOURCE <> N_CANCEL_SOURCE) OR ((P_CANCEL_SOURCE IS NULL) AND (N_CANCEL_SOURCE IS NOT NULL)) OR
       ((P_CANCEL_SOURCE IS NOT NULL) AND (N_CANCEL_SOURCE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'CANCEL_SOURCE',RTRIM(CAST(N_CANCEL_SOURCE AS CHAR(250))),RTRIM(CAST(P_CANCEL_SOURCE  AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    -- IF ((P_INCUR_INCENTIVE <> N_INCUR_INCENTIVE) OR ((P_INCUR_INCENTIVE IS NULL) AND (N_INCUR_INCENTIVE IS NOT NULL)) OR
    --    ((P_INCUR_INCENTIVE IS NOT NULL) AND (N_INCUR_INCENTIVE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'INCUR_INCENTIVE',RTRIM(CAST(N_INCUR_INCENTIVE AS CHAR(250))),RTRIM(CAST(P_INCUR_INCENTIVE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_INCUR_DISCOUNT <> N_INCUR_DISCOUNT) OR ((P_INCUR_DISCOUNT IS NULL) AND (N_INCUR_DISCOUNT IS NOT NULL)) OR
    --    ((P_INCUR_DISCOUNT IS NOT NULL) AND (N_INCUR_DISCOUNT IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'INCUR_DISCOUNT',RTRIM(CAST(N_INCUR_DISCOUNT AS CHAR(250))),RTRIM(CAST(P_INCUR_DISCOUNT AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_INCUR_ADMIN_CHG <> N_INCUR_ADMIN_CHG) OR ((P_INCUR_ADMIN_CHG IS NULL) AND (N_INCUR_ADMIN_CHG IS NOT NULL)) OR
    --    ((P_INCUR_ADMIN_CHG IS NOT NULL) AND (N_INCUR_ADMIN_CHG IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'INCUR_ADMIN_CHG',RTRIM(CAST(N_INCUR_ADMIN_CHG AS CHAR(250))),RTRIM(CAST(P_INCUR_ADMIN_CHG AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_RIDER_SIGN_CODE <> N_RIDER_SIGN_CODE) OR ((P_RIDER_SIGN_CODE IS NULL) AND (N_RIDER_SIGN_CODE IS NOT NULL)) OR
    --    ((P_RIDER_SIGN_CODE IS NOT NULL) AND (N_RIDER_SIGN_CODE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'RIDER_SIGN_CODE',RTRIM(CAST(N_RIDER_SIGN_CODE AS CHAR(250))),RTRIM(CAST(P_RIDER_SIGN_CODE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_Miles_Override <> N_Miles_Override) OR ((P_Miles_Override IS NULL) AND (N_Miles_Override IS NOT NULL)) OR
    --    ((P_Miles_Override IS NOT NULL) AND (N_Miles_Override IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'MILES_OVERRIDE',RTRIM(CAST(N_Miles_Override AS CHAR(250))),RTRIM(CAST(P_Miles_Override AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_Miles_OR_Approved_By <> N_Miles_OR_Approved_By) OR ((P_Miles_OR_Approved_By IS NULL) AND (N_Miles_OR_Approved_By IS NOT NULL)) OR
    --    ((P_Miles_OR_Approved_By IS NOT NULL) AND (N_Miles_OR_Approved_By IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'MILES_OR_APPR_BY',RTRIM(CAST(N_Miles_OR_Approved_By AS CHAR(250))),RTRIM(CAST(P_Miles_OR_Approved_By AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_Total_Cost_Adjustments <> N_Total_Cost_Adjustments) OR ((P_Total_Cost_Adjustments IS NULL) AND (N_Total_Cost_Adjustments IS NOT NULL)) OR
    --    ((P_Total_Cost_Adjustments IS NOT NULL) AND (N_Total_Cost_Adjustments IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TOT_COST_ADJUST',RTRIM(CAST(N_Total_Cost_Adjustments AS CHAR(250))),RTRIM(CAST(P_Total_Cost_Adjustments AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_SCHEDULED_WAIT_CHARGE <> N_SCHEDULED_WAIT_CHARGE) OR ((P_SCHEDULED_WAIT_CHARGE IS NULL) AND (N_SCHEDULED_WAIT_CHARGE IS NOT NULL)) OR
    --    ((P_SCHEDULED_WAIT_CHARGE IS NOT NULL) AND (N_SCHEDULED_WAIT_CHARGE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'SCHED_WAIT_CHARGE',RTRIM(CAST(N_SCHEDULED_WAIT_CHARGE AS CHAR(250))),RTRIM(CAST(P_SCHEDULED_WAIT_CHARGE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_SCHEDULED_WAIT_TIME <> N_SCHEDULED_WAIT_TIME) OR ((P_SCHEDULED_WAIT_TIME IS NULL) AND (N_SCHEDULED_WAIT_TIME IS NOT NULL)) OR
    --    ((P_SCHEDULED_WAIT_TIME IS NOT NULL) AND (N_SCHEDULED_WAIT_TIME IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'SCHED_WAIT_TIME',RTRIM(CAST(N_SCHEDULED_WAIT_TIME AS CHAR(250))),RTRIM(CAST(P_SCHEDULED_WAIT_TIME AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_SCHEDULED_ASSIST_CHARGE <> N_SCHEDULED_ASSIST_CHARGE) OR ((P_SCHEDULED_ASSIST_CHARGE IS NULL) AND (N_SCHEDULED_ASSIST_CHARGE IS NOT NULL)) OR
    --    ((P_SCHEDULED_ASSIST_CHARGE IS NOT NULL) AND (N_SCHEDULED_ASSIST_CHARGE IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'SCHED_ASSIST_CHRG',RTRIM(CAST(N_SCHEDULED_ASSIST_CHARGE AS CHAR(250))),RTRIM(CAST(P_SCHEDULED_ASSIST_CHARGE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_WAIT_CHG_APPROVED_BY <> N_WAIT_CHG_APPROVED_BY) OR ((P_WAIT_CHG_APPROVED_BY IS NULL) AND (N_WAIT_CHG_APPROVED_BY IS NOT NULL)) OR
    --    ((P_WAIT_CHG_APPROVED_BY IS NOT NULL) AND (N_WAIT_CHG_APPROVED_BY IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'WAIT_CHG_APPR_BY',RTRIM(CAST(N_WAIT_CHG_APPROVED_BY AS CHAR(250))),RTRIM(CAST(P_WAIT_CHG_APPROVED_BY AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((P_ASSIST_CHG_APPROVED_BY <> N_ASSIST_CHG_APPROVED_BY) OR ((P_ASSIST_CHG_APPROVED_BY IS NULL) AND (N_ASSIST_CHG_APPROVED_BY IS NOT NULL)) OR
    --    ((P_ASSIST_CHG_APPROVED_BY IS NOT NULL) AND (N_ASSIST_CHG_APPROVED_BY IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'ASSIST_CHG_APPR_BY',RTRIM(CAST(N_ASSIST_CHG_APPROVED_BY AS CHAR(250))),RTRIM(CAST(P_ASSIST_CHG_APPROVED_BY AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    IF ((p_AML_Updated_On <> n_AML_Updated_On) OR ((p_AML_Updated_On IS NULL) AND (N_AML_Updated_On IS NOT NULL)) OR
       ((p_AML_Updated_On IS NOT NULL) AND (n_AML_Updated_On IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'AML_UPDATED_ON',RTRIM(CAST(N_AML_Updated_On AS CHAR(250))),RTRIM(CAST(p_AML_Updated_On AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;

    -- IF ((p_Requested_PU_Time <> n_Requested_PU_Time) OR ((p_Requested_PU_Time IS NULL) AND (N_Requested_PU_Time IS NOT NULL)) OR
    --    ((p_Requested_PU_Time IS NOT NULL) AND (n_Requested_PU_Time IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'REQ_PU_TIME',RTRIM(CAST(N_Requested_PU_Time AS CHAR(250))),RTRIM(CAST(p_Requested_PU_Time AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((p_TP_Dispatched_Time <> n_TP_Dispatched_Time) OR ((p_TP_Dispatched_Time IS NULL) AND (N_TP_Dispatched_Time IS NOT NULL)) OR
    --    ((p_TP_Dispatched_Time IS NOT NULL) AND (n_TP_Dispatched_Time IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'TP_DISP_TIME',RTRIM(CAST(N_TP_Dispatched_Time AS CHAR(250))),RTRIM(CAST(p_TP_Dispatched_Time AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;

    -- IF ((p_Billed_Cost <> n_Billed_Cost) OR ((p_Billed_Cost IS NULL) AND (N_Billed_Cost IS NOT NULL)) OR
    --    ((p_Billed_Cost IS NOT NULL) AND (n_Billed_Cost IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'BILLED_COST',RTRIM(CAST(N_Billed_Cost AS CHAR(250))),RTRIM(CAST(p_Billed_Cost AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;
    
    IF ((P_ASSISTANCE_TYPE_CODE <> N_ASSISTANCE_TYPE_CODE) OR ((P_ASSISTANCE_TYPE_CODE IS NULL) AND (N_ASSISTANCE_TYPE_CODE IS NOT NULL)) OR
       ((P_ASSISTANCE_TYPE_CODE IS NOT NULL) AND (N_ASSISTANCE_TYPE_CODE IS NULL)))
       THEN
          INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'ASSIST_TYPE_CODE',RTRIM(CAST(N_ASSISTANCE_TYPE_CODE AS CHAR(250))),RTRIM(CAST(P_ASSISTANCE_TYPE_CODE AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
          set x_Something_Changed = 1;
    END IF;
    
    -- IF ((P_CLIENT_AUTH_NUMBER <> N_CLIENT_AUTH_NUMBER) OR ((P_CLIENT_AUTH_NUMBER IS NULL) AND (N_CLIENT_AUTH_NUMBER IS NOT NULL)) OR
    --    ((P_CLIENT_AUTH_NUMBER IS NOT NULL) AND (N_CLIENT_AUTH_NUMBER IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'CLIENT_AUTH_NUMBER',RTRIM(CAST(N_CLIENT_AUTH_NUMBER AS CHAR(250))),RTRIM(CAST(P_CLIENT_AUTH_NUMBER AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;
    
    -- IF ((P_OVERRIDE_COST <> N_OVERRIDE_COST) OR ((P_OVERRIDE_COST IS NULL) AND (N_OVERRIDE_COST IS NOT NULL)) OR
    --    ((P_OVERRIDE_COST IS NOT NULL) AND (N_OVERRIDE_COST IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'OVERRIDE_COST',RTRIM(CAST(N_OVERRIDE_COST AS CHAR(250))),RTRIM(CAST(P_OVERRIDE_COST AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;
    
    -- IF ((P_MASS_TRANSIT_OR_APPROVED_BY <> N_MASS_TRANSIT_OR_APPROVED_BY) OR ((P_MASS_TRANSIT_OR_APPROVED_BY IS NULL) AND (N_MASS_TRANSIT_OR_APPROVED_BY IS NOT NULL)) OR
    --    ((P_MASS_TRANSIT_OR_APPROVED_BY IS NOT NULL) AND (N_MASS_TRANSIT_OR_APPROVED_BY IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'MT_OR_APPROVED_BY',RTRIM(CAST(N_MASS_TRANSIT_OR_APPROVED_BY AS CHAR(250))),RTRIM(CAST(P_MASS_TRANSIT_OR_APPROVED_BY AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;
    
    -- IF ((P_MEDICAL_FORM_OR_APPROVED_BY <> N_MEDICAL_FORM_OR_APPROVED_BY) OR ((P_MEDICAL_FORM_OR_APPROVED_BY IS NULL) AND (N_MEDICAL_FORM_OR_APPROVED_BY IS NOT NULL)) OR
    --    ((P_MEDICAL_FORM_OR_APPROVED_BY IS NOT NULL) AND (N_MEDICAL_FORM_OR_APPROVED_BY IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'MF_OR_APPROVED_BY',RTRIM(CAST(N_MEDICAL_FORM_OR_APPROVED_BY AS CHAR(250))),RTRIM(CAST(P_MEDICAL_FORM_OR_APPROVED_BY AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;
    
    -- IF ((P_BILLED_COST_OR_APPROVED_BY <> N_BILLED_COST_OR_APPROVED_BY) OR ((P_BILLED_COST_OR_APPROVED_BY IS NULL) AND (N_BILLED_COST_OR_APPROVED_BY IS NOT NULL)) OR
    --    ((P_BILLED_COST_OR_APPROVED_BY IS NOT NULL) AND (N_BILLED_COST_OR_APPROVED_BY IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'BC_OR_APPROVED_BY',RTRIM(CAST(N_BILLED_COST_OR_APPROVED_BY AS CHAR(250))),RTRIM(CAST(P_BILLED_COST_OR_APPROVED_BY AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;
    
    -- IF ((P_Spenddown <> N_Spenddown) OR ((P_Spenddown IS NULL) AND (N_Spenddown IS NOT NULL)) OR
    --    ((P_Spenddown IS NOT NULL) AND (N_Spenddown IS NULL)))
    --    THEN
    --       INSERT INTO PRODUCTION.TRIP_LEG_AUDIT VALUES(P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,'SPENDDOWN',RTRIM(CAST(N_Spenddown AS CHAR(250))),RTRIM(CAST(P_Spenddown AS CHAR(250))),P_USER_CODE,NOW,n_Belongs_To_Call_Center_Code);
    --       set x_Something_Changed = 1;
    -- END IF;
    


    CLOSE CURSOR1;

   -- Insert into TP Notify if necessary
   -- only care about trip legs today or in the future and not already cancelled that had something actually changed and written to the audit table
   SET n_Notify_days = (select coalesce(Download_Days_Past,3) from production.call_center_system_configuration where call_Center_Code = n_belongs_To_Call_Center_Code);
   
   IF ((p_date_of_trip + n_Notify_days days) >= current date) and (n_status >= 0) and (x_Something_Changed = 1)
      THEN
         IF ((P_STATUS < 0) and ((N_STATUS >= 0) OR (N_STATUS IS NULL)))
            THEN  -- Just been cancelled, only notify old TP that they no longer have it
               IF n_tp_code is NOT NULL
                  THEN
                     INSERT INTO PRODUCTION.NOTIFY_TP_TRIP_LEG (TP_CODE,CALL_CENTER_CODE,DATE_OF_TRIP,TRIP_ID,TRIP_LEG,CHANGE_TYPE_CODE,STATUS,ENTERED_BY,ENTERED_ON) values
                        (n_tp_code,p_cc_code,p_date_of_trip,p_trip_id,p_trip_leg,3,0,p_User_Code,CURRENT_TIMESTAMP - CURRENT TIMEZONE);
               END IF;
            ELSE
               IF p_tp_code is NOT NULL
                  THEN
                     IF n_tp_code is NULL
                        THEN -- only need to notify new tp about new trip
                           -- notify new TP
                           INSERT INTO PRODUCTION.NOTIFY_TP_TRIP_LEG (TP_CODE,CALL_CENTER_CODE,DATE_OF_TRIP,TRIP_ID,TRIP_LEG,CHANGE_TYPE_CODE,STATUS,ENTERED_BY,ENTERED_ON) values
                              (P_tp_code,p_cc_code,p_date_of_trip,p_trip_id,p_trip_leg,1,0,p_User_Code,CURRENT_TIMESTAMP - CURRENT TIMEZONE);
                        ELSE -- Both TP_COdes not null
                           IF n_tp_code <> p_tp_code
                              THEN
                                 -- cancel previous TP
                                 INSERT INTO PRODUCTION.NOTIFY_TP_TRIP_LEG (TP_CODE,CALL_CENTER_CODE,DATE_OF_TRIP,TRIP_ID,TRIP_LEG,CHANGE_TYPE_CODE,STATUS,ENTERED_BY,ENTERED_ON) values
                                    (n_tp_code,p_cc_code,p_date_of_trip,p_trip_id,p_trip_leg,3,0,p_User_Code,CURRENT_TIMESTAMP - CURRENT TIMEZONE);
                                 -- notify new TP
                                 INSERT INTO PRODUCTION.NOTIFY_TP_TRIP_LEG (TP_CODE,CALL_CENTER_CODE,DATE_OF_TRIP,TRIP_ID,TRIP_LEG,CHANGE_TYPE_CODE,STATUS,ENTERED_BY,ENTERED_ON) values
                                    (p_tp_code,p_cc_code,p_date_of_trip,p_trip_id,p_trip_leg,1,0,p_User_Code,CURRENT_TIMESTAMP - CURRENT TIMEZONE);
                              ELSE -- just a modification
                                 INSERT INTO PRODUCTION.NOTIFY_TP_TRIP_LEG (TP_CODE,CALL_CENTER_CODE,DATE_OF_TRIP,TRIP_ID,TRIP_LEG,CHANGE_TYPE_CODE,STATUS,ENTERED_BY,ENTERED_ON) values
                                    (p_tp_code,p_cc_code,p_date_of_trip,p_trip_id,p_trip_leg,2,0,p_User_Code,CURRENT_TIMESTAMP - CURRENT TIMEZONE);
                           END IF;
                     END IF;
                  ELSE
                     IF n_tp_code is NOT NULL
                        THEN -- notify old TP that they no longer have it
                           -- cancel previous TP
                           INSERT INTO PRODUCTION.NOTIFY_TP_TRIP_LEG (TP_CODE,CALL_CENTER_CODE,DATE_OF_TRIP,TRIP_ID,TRIP_LEG,CHANGE_TYPE_CODE,STATUS,ENTERED_BY,ENTERED_ON) values
                              (n_tp_code,p_cc_code,p_date_of_trip,p_trip_id,p_trip_leg,3,0,p_User_Code,CURRENT_TIMESTAMP - CURRENT TIMEZONE);
                        -- otherwise both old and new TP are null so there is no one to notify
                     END IF;
               END IF;
         END IF;
       END IF;

   -- Check if cancelled
    IF ((P_STATUS < 0) and ((N_STATUS >= 0) OR (N_STATUS IS NULL)))
       THEN
          -- See if it is a preschedule
          OPEN CURSOR2;
          FETCH CURSOR2 INTO z_Preschedule_Code;

          IF z_Preschedule_Code is NOT NULL
             THEN
               -- Need to decrement Number_Trips_Verified in Preschedule
               OPEN CURSOR3;
               FETCH CURSOR3 INTO z_LOS_CODE,z_START_DATE,z_EXPIRE_DATE,z_Next_Date_Of_Trip,z_USER_CODE,z_PRESCHED_DAYS_CODE,z_PCA,z_ADULT_ESCORTS,z_CHILD_ESCORTS,
                  z_CARSEATS,z_TRIP_REASON_CODE,z_TREAT_TYPE_CODE,z_COMMENTS_FOR_TP,z_REQUESTED_BY,z_REQD_BY_PHONE,z_REQD_BY_PHONE_AC,z_REQD_BY_REL,z_GAS_REIMB_OP_CODE,
                  z_GAS_REIMB_REL_CODE,z_TRIP_LOOKUP_A,z_TRIP_LOOKUP_B,z_TRIP_LOOKUP_C,z_TRIP_TEXT_A,z_TRIP_TEXT_B,z_TRIP_TEXT_C,z_TRIP_TEXT_D,z_TRIP_TEXT_E,z_STATUS,
                  z_DIAGNOSTIC_CODE,z_AUTHORIZED_BY_CODE,z_LAST_DATE_OF_TRIP,z_NUMBER_OF_TRIPS,z_NUM_TRIPS_LEFT,z_HOLIDAY_CODE,z_REGION_CODE,z_Condition,
                  z_Number_Trips_Verified,z_Expire_Reason_Code,z_Expire_Contact,z_Recertify_Date,z_Last_Updated_On,
                  z_PCA_CHG_APPROVED_BY, z_ADULT_ESC_CHG_APPROVED_BY, z_CHILD_ESC_CHG_APPROVED_BY,
                  z_ORDERING_MED_PROV_NAME,z_ORDERING_MED_PROV_ID
                  ;

               SET z_Number_Trips_Verified = z_Number_Trips_Verified - 1;

               CALL LCADUSER.P_Update_Presched(z_Preschedule_Code,z_LOS_CODE,z_START_DATE,z_EXPIRE_DATE,z_Next_Date_Of_Trip,z_USER_CODE,z_PRESCHED_DAYS_CODE,z_PCA,z_ADULT_ESCORTS,z_CHILD_ESCORTS,
                  z_CARSEATS,z_TRIP_REASON_CODE,z_TREAT_TYPE_CODE,z_COMMENTS_FOR_TP,z_REQUESTED_BY,z_REQD_BY_PHONE,z_REQD_BY_PHONE_AC,z_REQD_BY_REL,z_GAS_REIMB_OP_CODE,
                  z_GAS_REIMB_REL_CODE,z_TRIP_LOOKUP_A,z_TRIP_LOOKUP_B,z_TRIP_LOOKUP_C,z_TRIP_TEXT_A,z_TRIP_TEXT_B,z_TRIP_TEXT_C,z_TRIP_TEXT_D,z_TRIP_TEXT_E,z_STATUS,
                  z_DIAGNOSTIC_CODE,z_AUTHORIZED_BY_CODE,z_LAST_DATE_OF_TRIP,z_NUMBER_OF_TRIPS,z_NUM_TRIPS_LEFT,z_HOLIDAY_CODE,z_REGION_CODE,z_Condition,
                  z_Number_Trips_Verified,z_Expire_Reason_Code,z_Expire_Contact,z_Recertify_Date,z_Last_Updated_On,
                  z_PCA_CHG_APPROVED_BY, z_ADULT_ESC_CHG_APPROVED_BY, z_CHILD_ESC_CHG_APPROVED_BY,
                  z_ORDERING_MED_PROV_NAME,z_ORDERING_MED_PROV_ID,
                  z_Updated_On,SQLSTATE_OUT,SQLCODE_OUT,MESSAGE_TEXT_OUT);
          END IF;

          CLOSE CURSOR2;

    END IF;


    -- -- Trip Limits (only if cancelled)
    -- IF (p_Use_Trip_Limit_Module = 1)
    --    THEN
    --       IF ((p_Status < 0) and ((N_STATUS >= 0) OR (N_STATUS IS NULL)))
    --          THEN
    --             OPEN BC_Cursor;
    --             FETCH BC_Cursor into n_Rider_Code,n_BC_Code,n_Rider_Type_Code,n_Treat_Type_Code,z_Trip_LOS_Code;
    --             CLOSE BC_Cursor;
  
    --             BEGIN
    --             DECLARE x_More_Limits int;
    --             DECLARE z_Trip_Limit_Code int;
    --             DECLARE z_Trip_Limit_Type smallint;
    --             DECLARE SQLSTATE_OUT CHAR(5);
    --             DECLARE SQLCODE_OUT int;
    --             DECLARE Messgae_Text_Out varchar(1000);

    --             DECLARE EXIT HANDLER FOR NOT FOUND
    --               BEGIN
    --                  SET x_More_Limits = 0;
    --               END;

    --            set x_More_Limits = 1;
    --            OPEN Limit_Cursor;
    --            FETCH Limit_Cursor into z_Trip_Limit_Code,z_Trip_Limit_Type;
    --            while (x_More_Limits = 1) do
    --               CALL lcaduser.p_Trip_Limit_Decrement(n_Rider_Code,z_Trip_Limit_Code,z_Trip_Limit_Type,p_CC_Code,p_Date_Of_Trip,p_Trip_ID,p_Trip_Leg,SQLSTATE_OUT,SQLCODE_OUT,Message_Text_Out);
    --               IF ((SQLSTATE_OUT <> '00000') and (SQLSTATE_OUT is not null))
    --                  THEN SIGNAL SQLSTATE SQLSTATE_OUT SET MESSAGE_TEXT = Message_Text_Out;
    --               END IF;

    --               set x_More_Limits = 1;
    --               FETCH Limit_Cursor into z_Trip_Limit_Code,z_Trip_Limit_Type;
    --            END WHILE;
    --            CLOSE Limit_Cursor;
    --            END;
    --       END IF;
    --       
    --       IF (z_Trip_Limit_Criteria_Changed = 1 AND p_Status > 0)
    --          THEN CALL LCADUSER.P_TRIP_LIMIT_CHANGE_TL_INFO(n_Miles,p_Miles,p_Limit_Override_Reason_Code,
    --                P_CC_CODE,P_DATE_OF_TRIP,P_TRIP_ID,P_TRIP_LEG,p_Status,p_Limit_Override_By,
    --                SQLSTATE_OUT,SQLCODE_OUT,Message_Text_Out); 
    --                                           
    --               IF ((SQLSTATE_OUT <> '00000') and (SQLSTATE_OUT is not null))
    --                  THEN SIGNAL SQLSTATE SQLSTATE_OUT SET MESSAGE_TEXT = Message_Text_Out;
    --               END IF;
    --       END IF;
    -- END IF;
    
    -- Batch Auto Assign Reroute LOG-1386
    IF (P_TP_CODE IS NULL) AND (N_TP_CODE IS NOT NULL)
       THEN UPDATE PRODUCTION.BAA_TRIPS 
            SET WAS_REROUTED = 1 
            where CALL_CENTER_CODE = P_CC_CODE and
            DATE_OF_TRIP = P_DATE_OF_TRIP and
            TRIP_ID = P_TRIP_ID and
            TRIP_LEG = P_TRIP_LEG and
            TP_CODE = N_TP_CODE
            ;
    END IF;
    

    SET p_Verified_By = z_Verified_By;
    SET p_Verified_On = z_Verified_On;
    SET P_UPDATED_ON = NOW;
    set p_Region_Code = n_Region_Code;
    set p_Broker_Client_Code = n_Broker_Client_Code;
    set p_Belongs_To_Call_Center_Code = n_Belongs_To_Call_Center_Code;
    SET SQLSTATE_OUT = SQLSTATE;
    SET SQLCODE_OUT = SQLCODE;
    SET MESSAGE_TEXT_OUT = NULL;

END P1UTL@


